#给定某个器件在四种朝向下的三张NXN栅格图，预测该器件的放置位置和朝向
import torch, torch.nn as nn

class TinyDT(nn.Module):
    def __init__(self, N):
        super().__init__()
        self.N = N #栅格边长
        in_dim = (N*N)*3  #每个朝向三个通道，各通道展平后长度N²，所以输入维度是N²*3
        hid = 256
        self.encoder = nn.Sequential(
            nn.Linear(in_dim, hid), nn.ReLU(),
            nn.Linear(hid, hid), nn.ReLU(),
        )
        self.rot_emb = nn.Embedding(4, 32)  # 0/90/180/270
        self.head = nn.Linear(hid+32, N*N)

    def forward(self, tokens_dict): #输入某个器件在四种朝向下的三张NXN栅格图，预测该器件的放置位置和朝向
        logits_by_rot = {} #建一个字典，存每个旋转角度对应的logits
        for idx,rot in enumerate([0,90,180,270]):
            t = tokens_dict[rot]
            pos = torch.tensor(t["position"].reshape(-1), dtype=torch.float32)
            wire = torch.tensor(t["wire"].reshape(-1), dtype=torch.float32)
            bonus = torch.tensor(t["bonus"].reshape(-1), dtype=torch.float32) #展平
            x = torch.cat([pos, wire, bonus], dim=0) #拼接成一个长向量
            h = self.encoder(x) #送入编码器，得到隐藏向量
            #将旋转角度的嵌入向量拼接到隐藏向量后面
            h = torch.cat([h, self.rot_emb(torch.tensor(idx))], dim=0) #拼接旋转嵌入
            logits = self.head(h)
            illegal = torch.tensor(t["position"].reshape(-1), dtype=torch.float32)
            logits = logits - illegal*1e9 #硬约束：用 position 掩码（1=非法）把非法格子的 logit 减去一个超大常数 ≈ 置为 −∞
            logits_by_rot[rot] = logits
        return logits_by_rot

    def sample_action(self, tokens_dict):
        logits_by_rot = self(tokens_dict)
        best = None
        for rot, logits in logits_by_rot.items():
            probs = torch.softmax(logits, dim=0) #对每个朝向下的所有栅格位置计算概率分布
            idx = torch.multinomial(probs, 1).item() #从概率分布中采样一个栅格位置
            score = probs[idx].item() #该位置的采样概率作为评分
            if (best is None) or (score > best[0]): #选择评分最高的朝向和位置作为最终结果
                best = (score, rot, idx) #记录最高评分、对应朝向和位置索引
        _, rot, idx = best #解包最佳评分、朝向和位置索引
        gy, gx = divmod(idx, self.N) #将位置索引转换为二维栅格坐标
        return gx, gy, rot
    #multinomial 让策略不会每次都走贪心，便于在线搜寻更优解