import argparse, json, torch
from env import PCBEnv
from seq import chip_oriented_sequence
from model import TinyDT
from replay import PrioritizedReplay
import torch
import numpy as np

#给定放置顺序seq，让策略模型model在环境env里逐渐放置元件，生成一条轨迹traj及其得分score，供上层在线微调调用
def trajectory_generation(env, model, seq): #轨迹生成
    traj = [] #轨迹容器，是一个元件放置列表，元素格式为 (name, x, y, rot)
    for name in seq:
        tokens = env.state_token(name) #为下一个元件生成四个朝向的三通道图
        gx, gy, rot = model.sample_action(tokens) #在四个朝向里各自采样一个格点，选择概率最高的朝向和位置
        xmin,ymin = env.boundary[0] #取第一个点
        xmax,ymax = env.boundary[2] #取第三个点
        #boundary 是一个四点列表，分别是左下、右下、右上、左上
        W = xmax-xmin; H = ymax-ymin
        x = xmin + gx * (W/env.N) #将栅格坐标转换为实际坐标
        y = ymin + gy * (H/env.N)
        env.place(name, x, y, rot) #在环境中放置该元件
        traj.append((name, x, y, rot))
    wl, slw = env.score()
    lam1, lam2 = 1000.0, 0.01 #控制权重
    score = lam1 * (1.0/max(wl, 1e-6)) + lam2 * slw
    return traj, score

#输入一条轨迹traj_steps，计算其负对数概率损失，用于微调 TinyDT 模型
def traj_loss(model, traj_steps, normalize_w= True):# 计算轨迹的负对数概率损失
    logps = []
    for tokens, (gx,gy,rot) in traj_steps:
        logits_by_rot = model(tokens)               # {rot: N*N logits}
        idx = gy * model.N + gx                     # 展平索引
        logits = logits_by_rot[rot]                 # 选定朝向
        logp = torch.log_softmax(logits, dim=0)[idx]
        logps.append(logp)
    return -torch.stack(logps).sum() #把每步的 log 概率相加，取负号作为负对数似然 (NLL)，最小化它等价于让模型更倾向于复现这条轨迹里的动作（即行为克隆/最大似然）
#task 是 PCB 布局任务的描述字典； iters 是微调轮数； traj_per_iter 是每轮收集的合法轨迹数； batch_size 是每轮训练批次大小； lr 是学习率
def online_finetune(task, iters=10, traj_per_iter=100, batch_size=8, lr=1e-3):
    env = PCBEnv(task)
    model = TinyDT(task["grid_N"])
    opt = torch.optim.Adam(model.parameters(), lr=lr) #Adam 优化器
    buffer = PrioritizedReplay(alpha=1.0) #优先回放池，用于存储轨迹和分数，alpha=1.0 表示优先级完全按分数区分（越大越容易被采样）
    total_collected = 0
    for it in range(iters):
        collected = []
        while len(collected) < traj_per_iter:
            env.reset()
            seq = chip_oriented_sequence(task)

            #tokens：该器件四个朝向的三通道图（position / wire / bonus）
            traj = []; steps = []
            for name in seq:
                tokens = env.state_token(name)
                gx, gy, rot = model.sample_action(tokens) #在四个朝向里各自采样一个格点，选择概率最高的朝向和位置
                xmin,ymin = env.boundary[0]; xmax,ymax = env.boundary[2]
                W = xmax-xmin; H = ymax-ymin
                x = xmin + gx * (W/env.N)
                y = ymin + gy * (H/env.N)
                env.place(name, x, y, rot)
                traj.append((name, x, y, rot))
                steps.append((tokens, (gx,gy,rot))) #记录每步的 (tokens, action) 以便后续计算损失

            wl, slw = env.score()
            boundary_ok, spacing_ok, all_ok, *_ = env.legal_states()
            if boundary_ok and spacing_ok and all_ok:
                lam1, lam2 = 1000.0, 0.1
                score = lam1*(1.0/max(wl,1e-6)) + lam2*slw
                buffer.add((steps, traj), score) #存到buffer，并放进本轮的collected用于当次训练
                collected.append((steps, score))
        total_collected += len(collected)
        print(f"[iter {it}] collected={len(collected)}  total={total_collected}  buffer={len(buffer)}")

        # ---- 训练 ----
        # 从回放池取一批（这里示例简单用最近收集的，可以修改成从buffer按优先级采样）
        batch_items = buffer.topk(batch_size, with_scores=True)  # [(payload, score), ...]
        # payload 是你 add 时塞进去的 (steps, traj)
        steps_list = []
        scores = []
        for (payload, sc) in batch_items:
            steps, _traj = payload
            steps_list.append(steps)
            scores.append(float(sc))

        scores = np.array(scores, dtype=np.float32)

        # 归一化权重（与之前一致）
        w = (scores - scores.mean()) / (scores.std() + 1e-6)
        w = np.clip(w, -2.0, 2.0)
        w = np.exp(w)
        w = w / (w.mean() + 1e-6)

        opt.zero_grad()
        loss = 0.0
        for steps, wi in zip(steps_list, w):
            loss = loss + (traj_loss(model, steps) * float(wi))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

    env.reset()
    seq = chip_oriented_sequence(task)
    traj, _ = trajectory_generation(env, model, seq)
    return model, traj

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", type=str, default="tasks/sample_task.json")  # 不再 required
    ap.add_argument("--iters", type=int, default=80) #iters 微调轮数
    ap.add_argument("--traj_per_iter", type=int, default=6)
    args = ap.parse_args()

    task = json.load(open(args.task, "r"))
    model, traj = online_finetune(task, args.iters, args.traj_per_iter)
    torch.save(model.state_dict(), "ckpt.pt")
    print("[train] saved ckpt.pt; final traj len=", len(traj))

if __name__ == "__main__":
    main()
